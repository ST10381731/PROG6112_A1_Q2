/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package st10381731_prog6112_assignment1_question2;

/**
 *
 * @author emilio
 */
import java.io.InputStream;
import java.util.Random;
import java.util.Scanner;

public class GameMode {

    protected int maxTries;
    protected int randomNumber;
    protected int numTries;
    protected int lastGuess;

    public GameMode(int maxTries) {
        this.maxTries = maxTries;
        this.randomNumber = new Random().nextInt(100) + 1;
        this.numTries = 0;
        this.lastGuess = -1;
    }

    public void setRandomNumber(int randomNumber) { //for testing 
        this.randomNumber = randomNumber;
    }

    public int testGuess() { //for testing 
        Scanner scanner = new Scanner(System.in);
        System.out.print("Guess a number between 1 and 100: ");
        int guess = scanner.nextInt();
        numTries++;
        lastGuess = guess;
        return guess;
    }

    public boolean isGameOver() {
        return numTries >= maxTries || lastGuess == randomNumber;
    }

    public int guess() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Guess a number between 1 and 100: ");
        int guess = scanner.nextInt();
        numTries++;
        lastGuess = guess;
        return guess;
    }

    public void play() {
        System.out.println("Welcome to Guess the Number!");
        System.out.println("You have " + maxTries + " tries to guess the correct number.");

        while (!isGameOver()) {
            int guess = guess();
            if (guess == randomNumber) {
                System.out.println("Congratulations! You guessed the correct number!");
            } else if (guess < randomNumber) {
                System.out.println("Your guess is too low.");
            } else {
                System.out.println("Your guess is too high.");
            }
        }

        if (numTries >= maxTries) {
            System.out.println("Sorry, you ran out of tries. The correct number was " + randomNumber);
        }
    }
}
