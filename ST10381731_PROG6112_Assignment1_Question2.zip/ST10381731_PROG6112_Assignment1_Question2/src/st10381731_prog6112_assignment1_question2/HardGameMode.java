/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package st10381731_prog6112_assignment1_question2;

import java.util.Scanner;

/**
 *
 * @author emilio
 */
class HardGameMode extends GameMode {

    public HardGameMode() {
        super(5); // Hard mode allows only 5 tries
    }

    @Override
    public int guess() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Guess a number between 1 and 100 (Hard mode): ");
        int guess = scanner.nextInt();
        numTries++;
        return guess;
    }
}
