/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package st10381731_prog6112_assignment1_question2;

/**
 *
 * @author emilio
 */
import java.util.Scanner;

public class ST10381731_PROG6112_Assignment1_Question2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Select a game mode:");
        System.out.println("1. Normal Mode");
        System.out.println("2. Hard Mode");
        int modeChoice = Integer.parseInt(scanner.nextLine());

        GameMode game;

        if (modeChoice == 2) {
            game = new HardGameMode();
        } else {
            game = new GameMode(10); // Normal mode allows 10 tries
        }

        game.play();

        // 2D array to store scores
        int[][] scores = new int[2][2]; // 2 rows for game modes, 2 columns for score and maxTries
        scores[0][0] = game.numTries;
        scores[0][1] = game.maxTries;
        scores[1][0] = game.randomNumber;
        scores[1][1] = modeChoice;

        System.out.println("Game over. Your score has been recorded.");

        // Print scores
        System.out.println("Scores:");
        System.out.println("Mode\tTries\tMaxTries\tNumber");
        System.out.println("Normal\t" + scores[0][0] + "\t" + scores[0][1] + "\t\t" + scores[1][0]);
        System.out.println("Hard\t" + scores[0][0] + "\t" + scores[0][1] + "\t\t" + scores[1][0]);
    }
}
