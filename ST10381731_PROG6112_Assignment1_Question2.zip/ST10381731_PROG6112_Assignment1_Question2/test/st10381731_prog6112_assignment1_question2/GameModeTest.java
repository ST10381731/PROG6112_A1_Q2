/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package st10381731_prog6112_assignment1_question2;

import java.io.ByteArrayInputStream;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author emilio
 */
public class GameModeTest {

    private GameMode game;

    public GameModeTest() {
    }

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public void setUp() {

        String testInput = "42\n";
        ByteArrayInputStream inputStream = new ByteArrayInputStream(testInput.getBytes());
        System.setIn(inputStream);

        game = new GameMode(10);
    }

    @Test
    public void testIsGameOverWhenMaxTriesNotExceeded() {

        game.setRandomNumber(42);

        ByteArrayInputStream in = new ByteArrayInputStream("40".getBytes());
        System.setIn(in);

        game.guess();
        assertFalse(game.isGameOver());
    }

    @Test
    public void testIsGameOverWhenCorrectGuess() {
        game.setRandomNumber(42);

        ByteArrayInputStream in = new ByteArrayInputStream("42".getBytes());
        System.setIn(in);

        game.guess();
        assertTrue(game.isGameOver());
    }

    @Test
    public void testIsGameOverWhenMaxTriesExceeded() {
        ByteArrayInputStream in;

        game.setRandomNumber(42);
        in = new ByteArrayInputStream("40".getBytes());
        System.setIn(in);
        game.guess(); // 1
        in = new ByteArrayInputStream("40".getBytes());
        System.setIn(in);
        game.guess(); // 2
        in = new ByteArrayInputStream("40".getBytes());
        System.setIn(in);
        game.guess(); // 3
        in = new ByteArrayInputStream("40".getBytes());
        System.setIn(in);
        game.guess(); // 4
        in = new ByteArrayInputStream("40".getBytes());
        System.setIn(in);
        game.guess(); // 5
        in = new ByteArrayInputStream("40".getBytes());
        System.setIn(in);
        game.guess(); // 6
        in = new ByteArrayInputStream("40".getBytes());
        System.setIn(in);
        game.guess(); // 7
        in = new ByteArrayInputStream("40".getBytes());
        System.setIn(in);
        game.guess(); // 8
        in = new ByteArrayInputStream("40".getBytes());
        System.setIn(in);
        game.guess(); // 9
        in = new ByteArrayInputStream("40".getBytes());
        System.setIn(in);
        game.guess(); // 10
        assertTrue(game.isGameOver());
    }
}
